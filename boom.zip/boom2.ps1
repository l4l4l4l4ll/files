Start-Process -FilePath "$env:temp/boom/mpg123.exe" -WindowStyle Hidden -ArgumentList "--loop -1 $env:temp/boom/boom.mp3"
while ($true) {
  ./boom/nircmd.exe mutesysvolume 0
  ./boom/nircmd.exe setsysvolume 2621
  Start-Sleep -Seconds 1
}